# Test Phase, this is here for test purposes only and is not intended to be used yet.
# DnD5eAutomatedSpells
This is a Colection of Spells to be used with automation with the modules Midi-QoL, DAE and Item Macro.
